
<?php
   $conn = mysqli_connect("localhost","root", "","contect") or die(mysql_error());
   ?>