<?php
   $conn = mysqli_connect("localhost","root", "","review") or die(mysql_error());
   ?>